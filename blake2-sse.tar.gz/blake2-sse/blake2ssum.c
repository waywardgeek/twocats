#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "blake2.h"

//#define DATA_SIZE (((size_t)1) << 23)
#define DATA_SIZE 2048

static struct timeval tm1;

static inline void start()
{
    gettimeofday(&tm1, NULL);
}

static inline void stop()
{
    struct timeval tm2;
    gettimeofday(&tm2, NULL);
    uint64_t t = (uint64_t)1000 * (tm2.tv_sec - tm1.tv_sec) + (tm2.tv_usec - tm1.tv_usec) / 1000;
    printf("%lu ms\n", t);
}

int main() {
    uint8_t *data = malloc(DATA_SIZE);
    memset(data, 0x55, DATA_SIZE);
    uint8_t out[32];
    start();
    uint32_t i;
    for(i = 0; i < 1000000; i++) {
        blake2s(out, data, NULL, 32, DATA_SIZE, 0);
        data[0] = out[0];
    }
    stop();
    for(i = 0; i < 32; i++) {
        printf("%02x", out[i]);
    }
    printf("\n");
    return 0;
}
